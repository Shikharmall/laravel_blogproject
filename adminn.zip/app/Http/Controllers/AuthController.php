<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Item;

class AuthController extends Controller
{

    public function login(Request $request)
    {

        
        $item =  Item::all();

        $email = $request->input('email');
        $password = $request->input('password');

        $user = User::where('email',$email)->get();

        $name = $user[0]->name;

        if(empty($user)){
           return back()->with('fail','This email is not registered.');
        }

        else{
            if($user[0]->password == $password){
               $request->session()->put('user' , $name);
               $request->session()->put('item',$item);

               return redirect('dashboard');
            }

            else{
              return back()->with('fail','Password not matched.');
            }
        }

        //return $user;*/

        //if($user[0]->password == $password){
        //    //$request->session()->put('loginId' , $user->id);
        //    return redirect('dashboard');
        // }

        // else{
        //   return back()->with('fail','Password not matched.');
        //}

        

    }


    public function dashboardview(Request $req)
    {   

        $location = $req->input('location');
        $status = $req->input('status');
        $type = $req->input('type');

        $lc = "All Location";
        $st = "All Status";
        $ty = "All type";

        if($lc == $location){
            if($st == $status){
                if($ty == $type){
                    $item =  Item::all();
                    $req->session()->put('item',$item);
                    return view('dashboard');
                    //return view('dashboard' , ["item"=>$item]);
                }
                else{
                    $item = Item::where('type', $type)->get();
                    $req->session()->put('item',$item);
                    return view('dashboard');
                    //return view('dashboard' , ["item"=>$item]);
                }
            }
            else{
                if($ty == $type){
                    $item = Item::where('status', $status)->get();
                    $req->session()->put('item',$item);
                    return view('dashboard');
                    //return view('dashboard' , ["item"=>$item]);
                }
                else{
                    $item = Item::where('status', $status)
                    ->where('type', $type)
                    ->get();
                    $req->session()->put('item',$item);
                    return view('dashboard');
                    //return view('dashboard' , ["item"=>$item]);
                }
            }

        }

        else{

            if($st == $status){
                if($ty == $type){
                    $item = Item::where('location', $location)->get();
                    $req->session()->put('item',$item);
                    return view('dashboard');
                    //return view('dashboard' , ["item"=>$item]);
                }
                else{
                    $item = Item::where('location', $location)
                    ->where('type', $type)->get();
                    $req->session()->put('item',$item);
                    return view('dashboard');
                    //return view('dashboard' , ["item"=>$item]);
                }
            }
            else{
                if($ty == $type){
                    $item = Item::where('location', $location)
                    ->where('status', $status)
                    ->get();
                    $req->session()->put('item',$item);
                    return view('dashboard');
                    //return view('dashboard' , ["item"=>$item]);
                }
                else{
                    $item = Item::where('location', $location)
                    ->where('status', $status)
                    ->where('type', $type)
                    ->get();
                    $req->session()->put('item',$item);
                    return view('dashboard');
                    //return view('dashboard' , ["item"=>$item]);
                }
            }
        }

    }
    
}