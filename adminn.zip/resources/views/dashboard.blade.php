@extends('layout')
@section('content')


<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand">Hello {{session('user')}}</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
    </ul>
    <div class="form-inline my-2 my-lg-0">
        <a class="nav-link" href="/">Log Out</a>
    </div>
  </div>
</nav>




<div>

  <form action="dashboard" method="POST">
    @csrf
    <h2 class="text-center text-muted">Track Consignment</h2>

    <div class="d-flex flex-row flex-wrap justify-content-center">


      <div class="form-group col-md-2 p-2">
        <!--<label for="inputState">Location</label>-->
        <select id="inputState" class="form-control" name="location">
          <option selected>All Location</option>
          <option>Delhi Hub</option>
          <option>Lucknow Hub</option>
          <option>Kanpur Hub</option>
          <option>Gorakhpur Hub</option>
        </select>
      </div>

      <div class="form-group col-md-2 p-2">
        <!--<label for="inputState">Status</label>-->
        <select id="inputState" class="form-control" name="status">
          <option selected>All Status</option>
          <option>Packed</option>
          <option>Shipped</option>
          <option>Delivered</option>
        </select>
      </div>

      <div class="form-group col-md-2 p-2">
        <!--<label for="inputState">Type</label>-->
        <select id="inputState" class="form-control" name="type">
          <option selected>All type</option>
          <option>Very Large parcel</option>
          <option>Large parcel</option>
          <option>Medium parcel</option>
          <option>Small parcel</option>
        </select>
      </div>

      <div class="form-group col-md-2 p-2 d-flex align-items-center">
        <button class="btn btn-outline-info my-2 my-sm-0" type="submit" >Search</button>
      </div>

    </div> 

  </form>



  <table class="table table-striped table-responsive-sm">
  <thead>
    <tr>
      <th scope="col">Item ID</th>
      <th scope="col">Item Name</th>
      <th scope="col">Location</th>
      <th scope="col">Type</th>
      <th scope="col">Status</th>
    </tr>
  </thead>

  <tbody>
    @php
     $item = session('item');
    @endphp
       
    @foreach($item as $itm)
      <tr>
        <th>{{$itm->id}}</th>
        <td>{{$itm->itmname}}</td>
        <td>{{$itm->location}}</td>
        <td>{{$itm->type}}</td>
        <td>{{$itm->status}}</td>
      </tr>
    @endforeach
    
</tbody>
</table>

</div>


















<br><br><br><br>
<!-- Footer -->
<footer class="text-center text-lg-start bg-light text-muted">
  <!-- Section: Social media -->
  <section class="d-flex justify-content-center justify-content-lg-between border-bottom">

  </section>
  <!-- Section: Social media -->

  <!-- Section: Links  -->
  <section class="">
    <div class="container text-center text-md-start mt-5">
      <!-- Grid row -->
      <div class="row mt-3">
        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
          <!-- Content -->
          <h6 class="text-uppercase fw-bold mb-4">
            <i class="fas fa-gem me-3"></i>Shikhar Courier Delivery
          </h6>
          <p>
            Together we work , together we win.
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">
            Services
          </h6>
          <p>
            <a href="#!" class="text-reset">Express Parcel</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Partial-truckload freight</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Truckload freight</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Supply chain services</a>
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">
            Useful links
          </h6>
          <p>
            <a href="#!" class="text-reset">Pricing</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Settings</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Orders</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Help</a>
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
          <p><i class="fas fa-home me-3"></i> New delhi, ND 10012, India</p>
          <p>
            <i class="fas fa-envelope me-3"></i>
            shikharcourierdelivery.com
          </p>
          <p><i class="fas fa-phone me-3"></i> + 01 234 567 88</p>
          <p><i class="fas fa-print me-3"></i> + 01 234 567 89</p>
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
  </section>
  <!-- Section: Links  -->

  <!-- Copyright -->
  <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
    © 2023 Copyright:
    <a class="text-reset fw-bold" href="https://mdbootstrap.com/">shikharcourierdelivery.com</a>
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->